/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.xwiki.administration.test.po;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.xwiki.test.ui.po.BootstrapSelect;

/**
 * Represents the actions possible on the Localization Administration Page.
 *
 * @version $Id: 9f4e554110f910ee0189d2d125233dced5eef970 $
 * @since 4.2M1
 */
public class LocalizationAdministrationSectionPage extends AdministrationSectionPage
{
    @FindBy(xpath = "(//div[contains(@class, 'bootstrap-select')])[1]")
    private WebElement multiLingualSelect;

    @FindBy(xpath = "(//div[contains(@class, 'bootstrap-select')])[3]")
    private WebElement defaultLanguageSelect;

    @FindBy(xpath = "(//div[contains(@class, 'bootstrap-select')])[2]")
    private WebElement supportedLanguagesSelect;

    public LocalizationAdministrationSectionPage()
    {
        super("Localization");
        // Wait for asynchronous widgets to be loaded
        getDriver().waitUntilElementIsVisible(By.cssSelector(".bootstrap-select"));
    }

    public void setMultiLingual(boolean isMultiLingual)
    {
        BootstrapSelect select = new BootstrapSelect(this.multiLingualSelect, getDriver());
        select.selectByValue(isMultiLingual ? "1" : "0");
    }

    public void setDefaultLanguage(String defaultLanguage)
    {
        BootstrapSelect select = new BootstrapSelect(this.defaultLanguageSelect, getDriver());
        select.selectByValue(defaultLanguage);
    }

    public void setSupportedLanguages(String supportedLanguages)
    {
        setSupportedLanguages(Arrays.asList(supportedLanguages.split(",")));
    }

    public void setSupportedLanguages(List<String> supportedLanguages)
    {
        BootstrapSelect select = new BootstrapSelect(this.supportedLanguagesSelect, getDriver());
        select.selectByValues(supportedLanguages);
    }
}
