Skeletons of Maven pom used to generate Mockito bundles for submission to
Maven Central Repository.

Please, don't use the poms to compile Mockito with Maven2 - use Ant instead.
