/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */
package org.mockito.internal.util.reflection;

public class DummyParentClassForTests {

    @SuppressWarnings("unused")//I know, I know. We're doing nasty reflection hacks here...
    private String somePrivateField;
}
