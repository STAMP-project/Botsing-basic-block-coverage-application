/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */
package org.mockitousage.stubbing;

import org.junit.Test;
import org.mockitoutil.TestBase;

//FIXME add test to demonstrate usage
public class ReturningMockValuesTest extends TestBase {

    @Test
    public void should() throws Exception {
        
    }
}
