package org.mockitousage.debugging;

interface Foo {
    String giveMeSomeString(String param);
    void doSomething(String param);
}
