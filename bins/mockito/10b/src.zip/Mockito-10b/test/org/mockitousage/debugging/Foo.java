/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */
package org.mockitousage.debugging;

interface Foo {
    String giveMeSomeString(String param);
    void doSomething(String param);
}
