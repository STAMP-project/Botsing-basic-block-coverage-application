/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */
package org.mockitousage.examples.use;

import java.util.List;

public class ArticleDatabase {

    public void updateNumberOfArticles(String newspaper, int articles) {
    }

    public void updateNumberOfPolishArticles(String newspaper, int polishArticles) {
    }

    public void updateNumberOfEnglishArticles(String newspaper, int i) {
    }

    public List<Article> getArticlesFor(String string) {
        return null;
    }

    public void save(Article article) {
    }
}
